
import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  Linking,
  ScrollView,
} from "react-native";

const products = [
  {
    id: "1",
    name: "کۆمەڵە خواردن 25 پارچە",
    price: 75000,
    category: "کۆمەڵە خواردن",
    image:
      "https://images.unsplash.com/photo-1577937927133-66ef06acd1c8?w=800",
  },
  {
    id: "2",
    name: "سێتی پیالە 12 پارچە",
    price: 45000,
    category: "پیالە و پیاڵەخانە",
    image:
      "https://images.unsplash.com/photo-1572119865084-43c285814d63?w=800",
  },
  {
    id: "3",
    name: "کاسە سێدە 6 پارچە",
    price: 30000,
    category: "کاسە و جام",
    image:
      "https://images.unsplash.com/photo-1610701596007-11502861d457?w=800",
  },
];

export default function App() {
  const [cart, setCart] = useState([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const addToCart = (product) => {
    const exists = cart.find((item) => item.id === product.id);

    if (exists) {
      setCart(
        cart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const increase = (id) => {
    setCart(
      cart.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  };

  const decrease = (id) => {
    setCart(
      cart
        .map((item) =>
          item.id === id
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const sendOrder = async () => {
    if (cart.length === 0) {
      Alert.alert("سەبەت بەتاڵە", "تکایە بەرهەمێک زیاد بکە.");
      return;
    }

    if (!name || !phone || !address) {
      Alert.alert(
        "زانیاری کەمە",
        "تکایە ناو، ژمارەی مۆبایل و ناونیشان پڕ بکەرەوە."
      );
      return;
    }

    let message = `🛍️ داواکاری نوێ - ASYA\n\n`;
    message += `👤 ناو: ${name}\n`;
    message += `📱 مۆبایل: ${phone}\n`;
    message += `📍 ناونیشان: ${address}\n\n`;
    message += `📦 بەرهەمەکان:\n`;

    cart.forEach((item) => {
      message += `• ${item.name}\n`;
      message += `  ژمارە: ${item.quantity}\n`;
      message += `  نرخ: ${(item.price * item.quantity).toLocaleString()} IQD\n\n`;
    });

    message += `💰 کۆی گشتی: ${total.toLocaleString()} IQD`;

    const url = `https://wa.me/9647718758585?text=${encodeURIComponent(
      message
    )}`;

    try {
      await Linking.openURL(url);
    } catch {
      Alert.alert("هەڵە", "WhatsApp نەکرایەوە.");
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.logo}>ASYA</Text>
          <Text style={styles.subtitle}>SHWSHAWATY ASYA</Text>
        </View>

        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>کۆمەڵە خواردن</Text>
          <Text style={styles.bannerText}>نوێ و تایبەت بۆ تۆ ✨</Text>
        </View>

        <TextInput
          style={styles.search}
          placeholder="بگەڕێ بۆ بەرهەم..."
          textAlign="right"
        />

        <Text style={styles.sectionTitle}>بەرهەمە نوێکان</Text>

        <FlatList
          data={products}
          numColumns={2}
          scrollEnabled={false}
          keyExtractor={(item) => item.id}
          columnWrapperStyle={{ justifyContent: "space-between" }}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Image source={{ uri: item.image }} style={styles.image} />

              <Text style={styles.productName}>{item.name}</Text>

              <Text style={styles.price}>
                {item.price.toLocaleString()} IQD
              </Text>

              <TouchableOpacity
                style={styles.addButton}
                onPress={() => addToCart(item)}
              >
                <Text style={styles.addText}>+ سەبەت</Text>
              </TouchableOpacity>
            </View>
          )}
        />

        <View style={styles.cartBox}>
          <Text style={styles.cartTitle}>
            🛒 سەبەت ({cart.length})
          </Text>

          {cart.length === 0 ? (
            <Text style={styles.empty}>سەبەتەکەت بەتاڵە</Text>
          ) : (
            <>
              {cart.map((item) => (
                <View style={styles.cartItem} key={item.id}>
                  <Text style={styles.cartName}>{item.name}</Text>

                  <View style={styles.counter}>
                    <TouchableOpacity
                      style={styles.counterButton}
                      onPress={() => decrease(item.id)}
                    >
                      <Text>−</Text>
                    </TouchableOpacity>

                    <Text style={styles.quantity}>{item.quantity}</Text>

                    <TouchableOpacity
                      style={styles.counterButton}
                      onPress={() => increase(item.id)}
                    >
                      <Text>+</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}

              <Text style={styles.total}>
                کۆی گشتی: {total.toLocaleString()} IQD
              </Text>

              <TextInput
                style={styles.input}
                placeholder="ناوی کڕیار"
                value={name}
                onChangeText={setName}
                textAlign="right"
              />

              <TextInput
                style={styles.input}
                placeholder="ژمارەی مۆبایل"
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                textAlign="right"
              />

              <TextInput
                style={[styles.input, styles.address]}
                placeholder="ناونیشانی گەیاندن"
                value={address}
                onChangeText={setAddress}
                multiline
                textAlign="right"
              />

              <TouchableOpacity
                style={styles.orderButton}
                onPress={sendOrder}
              >
                <Text style={styles.orderText}>
                  📲 داواکاری بنێرە بۆ WhatsApp
                </Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0d0d0d",
  },

  header: {
    alignItems: "center",
    paddingVertical: 25,
    borderBottomWidth: 1,
    borderBottomColor: "#333",
  },

  logo: {
    color: "#e6ad24",
    fontSize: 46,
    fontWeight: "900",
  },

  subtitle: {
    color: "#fff",
    fontSize: 17,
    letterSpacing: 4,
  },

  banner: {
    margin: 20,
    padding: 25,
    backgroundColor: "#1e1e1e",
    borderRadius: 25,
  },

  bannerTitle: {
    color: "#e6ad24",
    fontSize: 36,
    fontWeight: "bold",
    textAlign: "right",
  },

  bannerText: {
    color: "#fff",
    fontSize: 20,
    textAlign: "right",
    marginTop: 10,
  },

  search: {
    backgroundColor: "#fff",
    marginHorizontal: 20,
    padding: 18,
    borderRadius: 18,
    fontSize: 18,
  },

  sectionTitle: {
    color: "#fff",
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "right",
    margin: 20,
  },

  card: {
    backgroundColor: "#1d1d1d",
    width: "46%",
    marginHorizontal: "2%",
    marginBottom: 20,
    padding: 10,
    borderRadius: 20,
  },

  image: {
    width: "100%",
    height: 170,
    borderRadius: 15,
  },

  productName: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "bold",
    textAlign: "right",
    marginTop: 10,
  },

  price: {
    color: "#e6ad24",
    fontSize: 18,
    fontWeight: "bold",
    marginVertical: 8,
  },

  addButton: {
    backgroundColor: "#e6ad24",
    padding: 12,
    borderRadius: 15,
  },

  addText: {
    color: "#000",
    textAlign: "center",
    fontSize: 18,
    fontWeight: "bold",
  },

  cartBox: {
    margin: 20,
    padding: 20,
    backgroundColor: "#1d1d1d",
    borderRadius: 25,
    marginBottom: 40,
  },

  cartTitle: {
    color: "#e6ad24",
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "right",
    marginBottom: 15,
  },

  empty: {
    color: "#aaa",
    textAlign: "center",
    fontSize: 18,
  },

  cartItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#444",
  },

  cartName: {
    color: "#fff",
    fontSize: 17,
    textAlign: "right",
    marginBottom: 8,
  },

  counter: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    gap: 15,
  },

  counterButton: {
    backgroundColor: "#e6ad24",
    width: 38,
    height: 38,
    borderRadius: 19,
    justifyContent: "center",
    alignItems: "center",
  },

  quantity: {
    color: "#fff",
    fontSize: 20,
  },

  total: {
    color: "#e6ad24",
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "right",
    marginVertical: 20,
  },

  input: {
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 16,
    fontSize: 17,
    marginBottom: 12,
  },

  address: {
    minHeight: 90,
  },

  orderButton: {
    backgroundColor: "#25D366",
    padding: 17,
    borderRadius: 18,
    marginTop: 5,
  },

  orderText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 18,
    fontWeight: "bold",
  },
});